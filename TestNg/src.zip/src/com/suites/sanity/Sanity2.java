package com.suites.sanity;

import org.testng.annotations.Test;

public class Sanity2 {

	
	@Test
	public void test2()
	{
		
		System.out.println("inside sanity");
	}
}
