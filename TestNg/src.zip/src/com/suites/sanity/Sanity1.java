package com.suites.sanity;

import org.testng.annotations.Test;

public class Sanity1 {

	@Test
	public void test1()
	{
		
		System.out.println("inside sanity");
	}
}
