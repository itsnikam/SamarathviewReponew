package com.suites.regression;

import org.testng.annotations.Test;

public class Testingannotations1 {

	
	@Test
	public void getReports()
	{
		
		System.out.println("Priting the reports");
	}
}
