package com.testng.dataprovider;

public class Testwork {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Xls_Reader xls = new Xls_Reader("C:\\Users\\Sony\\Desktop\\Testdata.xlsx");
		int row_count = xls.getRowCount("Testdata");
		int col_count = xls.getColumnCount("Testdata");
		System.out.println(row_count);
		System.out.println(col_count);
		
		Object[][] data =  new Object[row_count-1][col_count-1];
			
		
		
		for(int i=1;i<row_count+1;i++)
		{
			
			for(int j=0;j<col_count;j++){
			if(xls.getCellData("Testdata", 0, i)=="")
			{
				
				System.out.println("No data");
			}
			else{
				System.out.println(xls.getCellData("Testdata", j, i));
				data [i] [j]= xls.getCellData("Testdata", j, i);
			}
		}
		
		}
		
		
	}

}
